package com.example.servicecenterallinone.ui.gallery;

import android.os.Bundle;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import com.example.servicecenterallinone.R;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
import javax.net.ssl.HttpsURLConnection;



public class GalleryFragment extends Fragment {

    private GalleryViewModel galleryViewModel;
    private TextView textView;
    private EditText editTextID;
    private EditText editTextName;
    private EditText editTextSurname;
    private EditText editTextAddress;
    private EditText editTextPhone;
    private EditText editTextEmail;
    private EditText editTextClientHistory;
    private EditText editTextIdentification;
    private Button btnSendRequestPOST;
    private Button btnEditEntryClientPOST;
    private Button btnDownloadClient;
    int serverNumberGET = 0;
    int serverNumberPOST = 0;
    String errorText; int err = 0;
    String[] countries = { "id", "name", "surname", "address", "phone", "email", "history" };
    String identification = null;



    public View onCreateView(@NonNull LayoutInflater inflater,  ViewGroup container, Bundle savedInstanceState) {

        galleryViewModel = ViewModelProviders.of(this).get(GalleryViewModel.class);
        View root = inflater.inflate(R.layout.fragment_gallery, container, false);

        textView = (TextView)root.findViewById(R.id.textView);
        editTextID = (EditText) root.findViewById(R.id.editTextID);
        editTextName = (EditText) root.findViewById(R.id.editTextName);
        editTextSurname = (EditText) root.findViewById(R.id.editTextSurname);
        editTextAddress = (EditText) root.findViewById(R.id.editTextAddress);
        editTextPhone = (EditText) root.findViewById(R.id.editTextPhone);
        editTextEmail = (EditText) root.findViewById(R.id.editTextEmail);
        editTextClientHistory = (EditText) root.findViewById(R.id.editTextClientHistory);
        editTextIdentification = (EditText) root.findViewById(R.id.editTextIdentification);
        btnSendRequestPOST = (Button)root.findViewById(R.id.btnSendRequestPOST);   // Кнопка "Отправить"
        btnSendRequestPOST.requestFocus();
        btnEditEntryClientPOST = (Button)root.findViewById(R.id.btnEditEntryClientPOST);   // Кнопка "Изменить"
        btnDownloadClient = (Button)root.findViewById(R.id.btnDownloadClient);   // Кнопка "Загрузить форму"

        // Кнопка "Зарегестрировать клиента"
        btnSendRequestPOST.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerClient();
            }
        });

        // Кнопка "Изменить данные"
        btnEditEntryClientPOST.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editEntryClient();
            }
        });

        // Кнопка "Загрузить форму"
        btnDownloadClient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                downloadClient();
            }
        });


        textView.setMovementMethod(new ScrollingMovementMethod()); // Скроллинг textView
        // textView.setHorizontallyScrolling(true);


        // Обработка выпадающего окна
        Spinner spinner = (Spinner) root.findViewById(R.id.spinner);
        // Создаем адаптер ArrayAdapter с помощью массива строк и стандартной разметки элемета spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity().getApplicationContext(), android.R.layout.simple_spinner_item, countries);
        // Определяем разметку для использования при выборе элемента
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Применяем адаптер к элементу spinner
        spinner.setAdapter(adapter);
        AdapterView.OnItemSelectedListener itemSelectedListener = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Получаем выбранный объект
                String item = (String)parent.getItemAtPosition(position);
                if(item == "id")      identification = "id";
                if(item == "name")    identification = "name";
                if(item == "surname") identification = "surname";
                if(item == "address") identification = "address";
                if(item == "phone")   identification = "phone";
                if(item == "email")   identification = "email";
                if(item == "history") identification = "clientHistory";
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        };
        spinner.setOnItemSelectedListener(itemSelectedListener);


//        final TextView textView = root.findViewById(R.id.text_gallery);
//        galleryViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
//            @Override
//            public void onChanged(@Nullable String s) {
//                textView.setText(s);
//            }
//        });


        return root;
    }



    // Кнопка "Зарегестрировать клиента"
    public void registerClient() {
        err = 0; errorText = "Вы не указали: ";
        if(editTextName.getText().toString().equals(""))          { errorText = errorText + "Имя ";             err = 1; }
        if(editTextSurname.getText().toString().equals(""))       { errorText = errorText + "Фамилию ";         err = 1; }
        if(editTextAddress.getText().toString().equals(""))       { errorText = errorText + "Адрес ";           err = 1; }
        if(editTextPhone.getText().toString().equals(""))         { errorText = errorText + "Телефон ";         err = 1; }
        if(editTextEmail.getText().toString().equals(""))         { errorText = errorText + "Email ";           err = 1; }
        if(editTextClientHistory.getText().toString().equals("")) { errorText = errorText + "Историю клиента ";          }
        if(err == 0){
            Toast.makeText(getActivity().getApplicationContext(), "Запрос отправлен на сервер", Toast.LENGTH_LONG).show();
            editTextID.setText("");
            serverNumberPOST = 3;
            new MyAsyncTaskPOST().execute();
        }
        if(err == 1){
            Toast.makeText(getActivity().getApplicationContext(), errorText, Toast.LENGTH_LONG).show();
        }
    }



    // Кнопка "Изменить" Редактирование данных о клиенте
    public void editEntryClient(){
        // Проверка на пустое поле ввода индекса записи
        if(editTextIdentification.getText().toString().equals("")){
            Toast.makeText(getActivity().getApplicationContext(), "Вы не указали: Индекс формы", Toast.LENGTH_LONG).show();
        }
        else{
            Toast.makeText(getActivity().getApplicationContext(), "Запрос отправлен на сервер", Toast.LENGTH_LONG).show();
            serverNumberPOST = 2;
            new MyAsyncTaskPOST().execute();
        }
    }



    // Кнопка "Загрузить форму"
    public void downloadClient(){
        // Проверка на пустое поле ввода индекса записи
        if(editTextIdentification.getText().toString().equals("")){
            Toast.makeText(getActivity().getApplicationContext(), "Вы не указали Идентификатор", Toast.LENGTH_LONG).show();
        }
        else{
            Toast.makeText(getActivity().getApplicationContext(), "Запрос отправлен на сервер", Toast.LENGTH_LONG).show();
            serverNumberGET = 6;
            new MyAsyncTaskGET().execute();
        }
    }



    // Серверная часть   Отправка GET запроса
    class MyAsyncTaskGET extends AsyncTask<String, String, String> {
        String a = null;
        String b = null;
        String c = null;
        String server = null;
        String serverAndData = null;
        String answerHTTP = null;
        String id = null;
        String name = null;
        String surname = null;
        String address = null;
        String phone = null;
        String email = null;
        String clientHistory = null;
        @Override
        protected void onPreExecute() {
            a = identification;
            b = editTextIdentification.getText().toString();
            c = "client";
            super.onPreExecute();
        }
        @Override
        protected String doInBackground(String... params) {
            HttpClient httpclient = new DefaultHttpClient();
            // Передаём название таблицы и возвращаем все её данные
            if(serverNumberGET==4) { server = "http://cc33953.tmweb.ru/php/SC_ReturningTable.php"; serverAndData = server + "?a=" + a; }
            // Подаём Идентификатор записи клиента и возвращаем все его данные
            if(serverNumberGET==6) { server = "http://cc33953.tmweb.ru/php/SC_ReturnOneEntry.php"; serverAndData = server + "?a=" + a + "&b=" + b + "&c=" + c; }
            HttpGet httpget = new HttpGet(serverAndData);
            try {
                HttpResponse response = httpclient.execute(httpget);
                if (response.getStatusLine().getStatusCode() == 200) {
                    HttpEntity entity = response.getEntity();
                    answerHTTP = EntityUtils.toString(entity);
                }
            }
            catch (ClientProtocolException e) {
            }
            catch (IOException e) {
            }
            return null;
        }
        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            answerHTTP = outSpecialCharactersHTML (answerHTTP);
            try {
                JSONObject jsonClientInfo = new JSONObject(answerHTTP);
                id            = jsonClientInfo.getString("id");
                name          = jsonClientInfo.getString("name");
                surname       = jsonClientInfo.getString("surname");
                address       = jsonClientInfo.getString("address");
                phone         = jsonClientInfo.getString("phone");
                email         = jsonClientInfo.getString("email");
                clientHistory = jsonClientInfo.getString("clientHistory");                                                                                     ;
                editTextID.           setText(id);
                editTextName.         setText(name);
                editTextSurname.      setText(surname);
                editTextAddress.      setText(address);
                editTextPhone.        setText(phone);
                editTextEmail.        setText(email);                                                                                                                 ;
                editTextClientHistory.setText(clientHistory);                                                                                                         ;
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }



    // Серверная часть   Отправка POST запроса
    class MyAsyncTaskPOST extends AsyncTask<String, String, String> {
        String a = null;
        String b = null;
        String c = null;
        String answerHTTP; String server;
        String nameClient          = null;
        String surnameClient       = null;
        String addressClient       = null;
        String phoneClient         = null;
        String emailClient         = null;
        String clientHistoryClient = null;
        String indexClient         = null;
        @Override
        protected void onPreExecute() {
            a = "client"; b = "client"; c = "client";
            nameClient          = editTextName.getText().toString();
            surnameClient       = editTextSurname.getText().toString();
            addressClient       = editTextAddress.getText().toString();
            phoneClient         = editTextPhone.getText().toString();
            emailClient         = editTextEmail.getText().toString();
            clientHistoryClient = editTextClientHistory.getText().toString();
            indexClient         = editTextID.getText().toString();
            super.onPreExecute();
        }
        @Override
        protected String doInBackground(String... params) {
            if(serverNumberPOST == 2) server = "http://cc33953.tmweb.ru/php/SC_EditEntry.php";          // Изменение данных о клиенте
            if(serverNumberPOST == 3) server = "http://cc33953.tmweb.ru/php/SC_RecordRegistration.php"; // Добавление нового клиента
            HashMap<String, String> postDataParams = new HashMap<String, String>();
            postDataParams.put("a", a);
            postDataParams.put("b", b);
            postDataParams.put("c", c);
            postDataParams.put("nameClient", nameClient);
            postDataParams.put("surnameClient", surnameClient);
            postDataParams.put("addressClient", addressClient);
            postDataParams.put("phoneClient", phoneClient);
            postDataParams.put("emailClient", emailClient);
            postDataParams.put("clientHistoryClient", clientHistoryClient);
            postDataParams.put("indexClient", indexClient);
            answerHTTP = performPostCall(server, postDataParams);
            return null;
        }
        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
        }
    }



    public String performPostCall(String requestURL, HashMap<String, String> postDataParams) {
        URL url;
        String response = "";
        try {
            url = new URL(requestURL);

            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(15000);
            conn.setConnectTimeout(15000);
            conn.setRequestMethod("POST");
            conn.setDoInput(true);
            conn.setDoOutput(true);

            OutputStream os = conn.getOutputStream();
            BufferedWriter writer = new BufferedWriter(
                    new OutputStreamWriter(os, "UTF-8"));
            writer.write(getPostDataString(postDataParams));

            writer.flush();
            writer.close();
            os.close();
            int responseCode = conn.getResponseCode();

            if (responseCode == HttpsURLConnection.HTTP_OK) {
                String line;
                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                while ((line = br.readLine()) != null) {
                    response += line;
                }
            } else {
                response = "";

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return response;
    }



    private String getPostDataString(HashMap<String, String> params) throws UnsupportedEncodingException {
        StringBuilder result = new StringBuilder();
        boolean first = true;
        for (Map.Entry<String, String> entry : params.entrySet()) {
            if (first)
                first = false;
            else
                result.append("&");

            result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
        }

        return result.toString();
    }



    private String outSpecialCharactersHTML (String a){
        // Знаки пунктуации
        a = a.replaceAll("&nbsp;"," ");         // Неразрывный пробел
        a = a.replaceAll("&shy;","\n");         // Место возможного переноса
        a = a.replaceAll("&lt;","<");           // Знак "меньше чем" (начало тега)
        a = a.replaceAll("&gt;",">");           // Знак "больше чем" (конец тега)
        a = a.replaceAll("&laquo;","«");        // Левая двойная угловая скобка
        a = a.replaceAll("&raquo;","»");        // Правая двойная угловая скобка
        a = a.replaceAll("&lsaquo;","‹");       // Левая угловая одиночная кавычка
        a = a.replaceAll("&rsaquo;","›");       // Правая угловая одиночная кавычка
        a = a.replaceAll("&quot;","\"");        // Двойная кавычка
        a = a.replaceAll("&prime;","'");        // Одиночный штрих
        a = a.replaceAll("&Prime;","″");        // Двойной штрих
        a = a.replaceAll("&lsquo;","‘");        // Левая одиночная кавычка
        a = a.replaceAll("&rsquo;","’");        // Правая одиночная кавычка
        a = a.replaceAll("&sbquo;","‚");        // Нижняя одиночная кавычка
        a = a.replaceAll("&ldquo;","“");        // Левая двойная кавычка
        a = a.replaceAll("&rdquo;","”");        // Правая двойная кавычка
        a = a.replaceAll("&bdquo;","„");        // Нижняя двойная кавычка
        a = a.replaceAll("&#10076;","❜");       // Жирная одинарная верхняя запятая
        a = a.replaceAll("&#10075;","❛");       // Жирная одинарная повёрнутая верхняя запятая
        a = a.replaceAll("&apos;","'");         // Апостроф (одинарная кавычка)
        a = a.replaceAll("&sect;","§");         // Параграф
        a = a.replaceAll("&copy;","©");         // Знак copyright
        a = a.replaceAll("&not;","¬");          // Знак отрицания
        a = a.replaceAll("&reg;","®");          // Знак зарегистрированной торговой марки
        a = a.replaceAll("&macr;","¯");         // Знак долготы над гласным
        a = a.replaceAll("&deg;","°");          // Градус
        a = a.replaceAll("&plusmn;","±");       // Плюс-минус
        a = a.replaceAll("&sup1;","¹");         // Верхний индекс "1"
        a = a.replaceAll("&sup2;","²");         // Верхний индекс "2"
        a = a.replaceAll("&sup3;","³");         // Верхний индекс "3"
        a = a.replaceAll("&frac14;","¼");       // Одна четверть
        a = a.replaceAll("&frac12;","½");       // Одна вторая
        a = a.replaceAll("&frac34;","¾");       // Три четверти
        a = a.replaceAll("&acute;","´");        // Знак ударения
        a = a.replaceAll("&micro;","µ");        // Микро
        a = a.replaceAll("&para;","¶");         // Знак абзаца
        a = a.replaceAll("&middot;","·");       // Знак умножения
        a = a.replaceAll("&iquest;","¿");     // Перевернутый вопросительный знак
        a = a.replaceAll("&fnof;","ƒ");         // Знак флорина
        a = a.replaceAll("&trade;","™");        // Знак торговой марки
        a = a.replaceAll("&bull;","•");         // Маркер списка
        a = a.replaceAll("&hellip;","…");       // Многоточие
        a = a.replaceAll("&oline;","‾");        // Надчеркивание
        a = a.replaceAll("&ndash;","–");        // Среднее тире
        a = a.replaceAll("&mdash;","—");        // Длинное тире
        a = a.replaceAll("&#37;","%");          // Процент
        a = a.replaceAll("&permil;","‰");       // Промилле
        a = a.replaceAll("&#125;","}");         // Правая фигурная скобка
        a = a.replaceAll("&#123;","{");         // Левая фигурная скобка
        a = a.replaceAll("&#61;","=");          // Знак равенства
        a = a.replaceAll("&ne;","≠");           // Знак неравенства
        a = a.replaceAll("&cong;","≅");         // Конгруэнтность (геометрическое равенство)
        a = a.replaceAll("&asymp;","≈");        // Почти равно
        a = a.replaceAll("&le;","≤");           // Меньше чем или равно
        a = a.replaceAll("&ge;","≥");           // Больше чем или равно
        a = a.replaceAll("&ang;","∠");          // Угол
        a = a.replaceAll("&perp;","⊥");         // Перпендикулярно (кнопка вверх)
        a = a.replaceAll("&radic;","√");        // Квадратный корень
        a = a.replaceAll("&sum;","∑");          // N-ичное суммирование
        a = a.replaceAll("&int;","∫");          // Интеграл
        a = a.replaceAll("&#8251;","※");       // Знак сноски
        a = a.replaceAll("&divide;","÷");       // Знак деления
        a = a.replaceAll("&infin;","∞");        // Знак бесконечности
        a = a.replaceAll("&#64;","@");          // Символ собака
        a = a.replaceAll("&#91;","\\[");        // Левая квадратная скобка
        a = a.replaceAll("&#93;","\\]");        // Правая квадратная скобка
        // Стрелки
        a = a.replaceAll("&larr;","←");         // Стрелка влево
        a = a.replaceAll("&uarr;","↑");         // Стрелка вверх
        a = a.replaceAll("&rarr;","→");         // Стрелка вправо
        a = a.replaceAll("&darr;","↓");         // Стрелка вниз
        a = a.replaceAll("&harr;","↔");         // Стрелка влево-вправо
        a = a.replaceAll("&crarr;","↵");        // Стрелка вниз и влево – знак возврата каретки
        a = a.replaceAll("&lArr;","⇐");         // Двойная стрелка налево
        a = a.replaceAll("&uArr;","⇑");         // Двойная стрелка вверх
        a = a.replaceAll("&rArr;","⇒");         // Двойная стрелка направо
        a = a.replaceAll("&dArr;","⇓");         // Двойная стрелка вниз
        a = a.replaceAll("&hArr;","⇔");         // Двойная стрелка влево-вправо
        a = a.replaceAll("&#10144;","➠");       // Летящая стрела
        a = a.replaceAll("&#10148;","➤");       // Наконечник стрелы
        a = a.replaceAll("&#10149;","➥");       // Изогнутая стрела, указывающая вниз и вправо
        a = a.replaceAll("&#10150;","➦");       // Изогнутая стрела, указывающая вверх и вправо
        a = a.replaceAll("&#10163;","➳");       // Стрела направо
        a = a.replaceAll("&#8634;","↺");        // Круглая стрелка с наконечником против часовой стрелки
        a = a.replaceAll("&#8635;","↻");        // Круглая стрелка с наконечником по часовой стрелке
        a = a.replaceAll("&#8679;","⇧");        // Толстая полая стрелка вверх
        a = a.replaceAll("&#8617;","↩");        // Стрелка налево с крючком
        a = a.replaceAll("&#10155;","➫");       // Наклонённая вниз объёмная стрелка
        a = a.replaceAll("&#11015;","⬇");       // Закрашенная стрелка вниз
        a = a.replaceAll("&#11014;","⬆");       // Закрашенная стрелка вверх
        // Деньги
        a = a.replaceAll("&cent;","¢");         // Цент
        a = a.replaceAll("&pound;","£");        // Фунт стерлингов
        a = a.replaceAll("&#8381;","₽");        // Российский рубль
        a = a.replaceAll("&yen;","¥");          // Йена или юань
        a = a.replaceAll("&euro;","€");         // Евро
        a = a.replaceAll("&#36;","$");          // Доллар
        a = a.replaceAll("&#8372;","₴");        // Знак гривны
        a = a.replaceAll("&#8377;","₹");        // Индийская рупия
        a = a.replaceAll("&#22291;","圓");       // Китайский юань
        a = a.replaceAll("&#8376;","₸");        // Казахстанский тенге

        return a;
    }

}