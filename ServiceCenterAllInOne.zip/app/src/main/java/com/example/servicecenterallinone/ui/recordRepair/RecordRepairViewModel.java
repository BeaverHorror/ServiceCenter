package com.example.servicecenterallinone.ui.recordRepair;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

public class RecordRepairViewModel extends ViewModel {
    private MutableLiveData<String> mText;

    public RecordRepairViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is record_repair fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}

