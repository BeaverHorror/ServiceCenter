package com.example.servicecenterallinone.ui.home;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import com.example.servicecenterallinone.R;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.method.ScrollingMovementMethod;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import java.io.IOException;
import android.widget.ArrayAdapter;
import android.widget.Spinner;



public class HomeFragment extends Fragment {

    private HomeViewModel homeViewModel;
    private TextView textView;
    private Button btnReturningTableBD;
    ScaleGestureDetector mScaleGestureDetector;
    private float mScaleFactor = 1.0f;
    float textsize;
    int serverNumberGET = 0;
    int serverNumberPOST = 0;
    String[] countries = { "client", "delivery_for_repairs", "detail", "details_service_center",
            "details_used_work", "device", "device_type", "promotion", "record_repair",
            "record_repair_promotion", "repair_work", "repair_work_device_type", "service_center",
            "worker", "all_info", "all_info_device"};
    String identification = null;



    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        homeViewModel = ViewModelProviders.of(this).get(HomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_home, container, false);

        textView = (TextView)root.findViewById(R.id.textView);
        textsize = textView.getTextSize();
        mScaleGestureDetector = new ScaleGestureDetector(getActivity().getApplicationContext(), new ScaleListener());
        btnReturningTableBD = (Button)root.findViewById(R.id.btnReturningTableBD); // Кнопка "Загрузить таблицу"
        btnReturningTableBD.requestFocus();

        // Кнопка "Загрузить таблицу"
        btnReturningTableBD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                returningTable();
            }
        });

        textView.setMovementMethod(new ScrollingMovementMethod()); // Скроллинг textView
        textView.setHorizontallyScrolling(true);

        // Обработка выпадающего окна
        Spinner spinner = (Spinner) root.findViewById(R.id.spinner);
        // Создаем адаптер ArrayAdapter с помощью массива строк и стандартной разметки элемета spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity().getApplicationContext(), android.R.layout.simple_spinner_item, countries);
        // Определяем разметку для использования при выборе элемента
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Применяем адаптер к элементу spinner
        spinner.setAdapter(adapter);
        AdapterView.OnItemSelectedListener itemSelectedListener = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Получаем выбранный объект
                String item = (String)parent.getItemAtPosition(position);
                identification = item;
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        };
        spinner.setOnItemSelectedListener(itemSelectedListener);


        return root;
    }



    // Масштабируемость textView
    public boolean onTouchEvent(MotionEvent motionEvent) {
        mScaleGestureDetector.onTouchEvent(motionEvent);
        return true;
    }
    private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
        public boolean onScale(ScaleGestureDetector scaleGestureDetector){
            mScaleFactor *= scaleGestureDetector.getScaleFactor();
            mScaleFactor = Math.max(0.5f,Math.min(mScaleFactor, 5.0f));
            float newtextsize = textsize * mScaleFactor;
            textView.setTextSize(TypedValue.COMPLEX_UNIT_PX, newtextsize);
            return true;
        }
    }



    // Кнопка "Загрузить таблицу"
    public void returningTable() {
        textView.setText("");
        serverNumberGET = 4;
        new MyAsyncTaskGET().execute();
    }



    // Серверная часть   Отправка GET запроса
    class MyAsyncTaskGET extends AsyncTask<String, String, String> {

        String a, answerHTTP, server, serverData;
        @Override
        protected void onPreExecute() {
            a = identification;
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... params) {
            HttpClient httpclient = new DefaultHttpClient();
            if(serverNumberGET==4) { server = "http://cc33953.tmweb.ru/php/SC_ReturningTable.php"; serverData = server + "?a=" + a; }
            HttpGet httpget = new HttpGet(serverData);
            try {
                HttpResponse response = httpclient.execute(httpget);
                if (response.getStatusLine().getStatusCode() == 200) {
                    HttpEntity entity = response.getEntity();
                    answerHTTP = EntityUtils.toString(entity);
                }
            }
            catch (ClientProtocolException e) {
            }
            catch (IOException e) {
            }
            return null;
        }
        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            answerHTTP = outSpecialCharactersHTML (answerHTTP);
            textView.setText(answerHTTP);
        }
    }



    private String outSpecialCharactersHTML (String a){
        // Знаки пунктуации
        a = a.replaceAll("&nbsp;"," ");         // Неразрывный пробел
        a = a.replaceAll("&shy;","\n");         // Место возможного переноса
        a = a.replaceAll("&lt;","<");           // Знак "меньше чем" (начало тега)
        a = a.replaceAll("&gt;",">");           // Знак "больше чем" (конец тега)
        a = a.replaceAll("&laquo;","«");        // Левая двойная угловая скобка
        a = a.replaceAll("&raquo;","»");        // Правая двойная угловая скобка
        a = a.replaceAll("&lsaquo;","‹");       // Левая угловая одиночная кавычка
        a = a.replaceAll("&rsaquo;","›");       // Правая угловая одиночная кавычка
        a = a.replaceAll("&quot;","\"");        // Двойная кавычка
        a = a.replaceAll("&prime;","'");        // Одиночный штрих
        a = a.replaceAll("&Prime;","″");        // Двойной штрих
        a = a.replaceAll("&lsquo;","‘");        // Левая одиночная кавычка
        a = a.replaceAll("&rsquo;","’");        // Правая одиночная кавычка
        a = a.replaceAll("&sbquo;","‚");        // Нижняя одиночная кавычка
        a = a.replaceAll("&ldquo;","“");        // Левая двойная кавычка
        a = a.replaceAll("&rdquo;","”");        // Правая двойная кавычка
        a = a.replaceAll("&bdquo;","„");        // Нижняя двойная кавычка
        a = a.replaceAll("&#10076;","❜");       // Жирная одинарная верхняя запятая
        a = a.replaceAll("&#10075;","❛");       // Жирная одинарная повёрнутая верхняя запятая
        a = a.replaceAll("&apos;","'");         // Апостроф (одинарная кавычка)
        a = a.replaceAll("&sect;","§");         // Параграф
        a = a.replaceAll("&copy;","©");         // Знак copyright
        a = a.replaceAll("&not;","¬");          // Знак отрицания
        a = a.replaceAll("&reg;","®");          // Знак зарегистрированной торговой марки
        a = a.replaceAll("&macr;","¯");         // Знак долготы над гласным
        a = a.replaceAll("&deg;","°");          // Градус
        a = a.replaceAll("&plusmn;","±");       // Плюс-минус
        a = a.replaceAll("&sup1;","¹");         // Верхний индекс "1"
        a = a.replaceAll("&sup2;","²");         // Верхний индекс "2"
        a = a.replaceAll("&sup3;","³");         // Верхний индекс "3"
        a = a.replaceAll("&frac14;","¼");       // Одна четверть
        a = a.replaceAll("&frac12;","½");       // Одна вторая
        a = a.replaceAll("&frac34;","¾");       // Три четверти
        a = a.replaceAll("&acute;","´");        // Знак ударения
        a = a.replaceAll("&micro;","µ");        // Микро
        a = a.replaceAll("&para;","¶");         // Знак абзаца
        a = a.replaceAll("&middot;","·");       // Знак умножения
        a = a.replaceAll("&iquest;","¿");     // Перевернутый вопросительный знак
        a = a.replaceAll("&fnof;","ƒ");         // Знак флорина
        a = a.replaceAll("&trade;","™");        // Знак торговой марки
        a = a.replaceAll("&bull;","•");         // Маркер списка
        a = a.replaceAll("&hellip;","…");       // Многоточие
        a = a.replaceAll("&oline;","‾");        // Надчеркивание
        a = a.replaceAll("&ndash;","–");        // Среднее тире
        a = a.replaceAll("&mdash;","—");        // Длинное тире
        a = a.replaceAll("&#37;","%");          // Процент
        a = a.replaceAll("&permil;","‰");       // Промилле
        a = a.replaceAll("&#125;","}");         // Правая фигурная скобка
        a = a.replaceAll("&#123;","{");         // Левая фигурная скобка
        a = a.replaceAll("&#61;","=");          // Знак равенства
        a = a.replaceAll("&ne;","≠");           // Знак неравенства
        a = a.replaceAll("&cong;","≅");         // Конгруэнтность (геометрическое равенство)
        a = a.replaceAll("&asymp;","≈");        // Почти равно
        a = a.replaceAll("&le;","≤");           // Меньше чем или равно
        a = a.replaceAll("&ge;","≥");           // Больше чем или равно
        a = a.replaceAll("&ang;","∠");          // Угол
        a = a.replaceAll("&perp;","⊥");         // Перпендикулярно (кнопка вверх)
        a = a.replaceAll("&radic;","√");        // Квадратный корень
        a = a.replaceAll("&sum;","∑");          // N-ичное суммирование
        a = a.replaceAll("&int;","∫");          // Интеграл
        a = a.replaceAll("&#8251;","※");       // Знак сноски
        a = a.replaceAll("&divide;","÷");       // Знак деления
        a = a.replaceAll("&infin;","∞");        // Знак бесконечности
        a = a.replaceAll("&#64;","@");          // Символ собака
        a = a.replaceAll("&#91;","\\[");        // Левая квадратная скобка
        a = a.replaceAll("&#93;","\\]");        // Правая квадратная скобка
        // Стрелки
        a = a.replaceAll("&larr;","←");         // Стрелка влево
        a = a.replaceAll("&uarr;","↑");         // Стрелка вверх
        a = a.replaceAll("&rarr;","→");         // Стрелка вправо
        a = a.replaceAll("&darr;","↓");         // Стрелка вниз
        a = a.replaceAll("&harr;","↔");         // Стрелка влево-вправо
        a = a.replaceAll("&crarr;","↵");        // Стрелка вниз и влево – знак возврата каретки
        a = a.replaceAll("&lArr;","⇐");         // Двойная стрелка налево
        a = a.replaceAll("&uArr;","⇑");         // Двойная стрелка вверх
        a = a.replaceAll("&rArr;","⇒");         // Двойная стрелка направо
        a = a.replaceAll("&dArr;","⇓");         // Двойная стрелка вниз
        a = a.replaceAll("&hArr;","⇔");         // Двойная стрелка влево-вправо
        a = a.replaceAll("&#10144;","➠");       // Летящая стрела
        a = a.replaceAll("&#10148;","➤");       // Наконечник стрелы
        a = a.replaceAll("&#10149;","➥");       // Изогнутая стрела, указывающая вниз и вправо
        a = a.replaceAll("&#10150;","➦");       // Изогнутая стрела, указывающая вверх и вправо
        a = a.replaceAll("&#10163;","➳");       // Стрела направо
        a = a.replaceAll("&#8634;","↺");        // Круглая стрелка с наконечником против часовой стрелки
        a = a.replaceAll("&#8635;","↻");        // Круглая стрелка с наконечником по часовой стрелке
        a = a.replaceAll("&#8679;","⇧");        // Толстая полая стрелка вверх
        a = a.replaceAll("&#8617;","↩");        // Стрелка налево с крючком
        a = a.replaceAll("&#10155;","➫");       // Наклонённая вниз объёмная стрелка
        a = a.replaceAll("&#11015;","⬇");       // Закрашенная стрелка вниз
        a = a.replaceAll("&#11014;","⬆");       // Закрашенная стрелка вверх
        // Деньги
        a = a.replaceAll("&cent;","¢");         // Цент
        a = a.replaceAll("&pound;","£");        // Фунт стерлингов
        a = a.replaceAll("&#8381;","₽");        // Российский рубль
        a = a.replaceAll("&yen;","¥");          // Йена или юань
        a = a.replaceAll("&euro;","€");         // Евро
        a = a.replaceAll("&#36;","$");          // Доллар
        a = a.replaceAll("&#8372;","₴");        // Знак гривны
        a = a.replaceAll("&#8377;","₹");        // Индийская рупия
        a = a.replaceAll("&#22291;","圓");       // Китайский юань
        a = a.replaceAll("&#8376;","₸");        // Казахстанский тенге

        return a;
    }
}