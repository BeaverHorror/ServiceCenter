package com.example.servicecenterallinone.ui.recordRepair;

import android.arch.lifecycle.ViewModelProviders;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.example.servicecenterallinone.R;
import com.example.servicecenterallinone.ui.recordRepair.RecordRepairFragment;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
import java.util.Observer;

import javax.net.ssl.HttpsURLConnection;



public class RecordRepairFragment extends Fragment {

    private RecordRepairViewModel record_repairViewModel;

    private TextView textView;

    private EditText editTextID;
    private EditText editTextStartData;
    private EditText editTextEndData;
    private EditText editTextPaymentMethod;
    private EditText editTextQuality;
    private EditText editTextUrgency;
    private EditText editTextGuarantee;
    private EditText editTextProblemDescription;
    private EditText editTextComment;
    private EditText editTextReviewWorker;
    private EditText editTextClientID;
    private EditText editTextDeliveryForRepairsID;
    private EditText editTextWorkerID;
    private EditText editTextRepairWorkID;
    private EditText editTextDeviceID;
    private EditText editTextServiceCenterID;

    private EditText editTextIdentification;

    private Button btnSendRequestPOST;
    private Button btnEditEntryClientPOST;
    private Button btnDownloadClient;

    int serverNumberGET = 0;
    int serverNumberPOST = 0;

    String errorText;
    int err = 0;

    String[] countries = { "id", "start_data", "end_data", "payment_method", "quality", "urgency",
            "guarantee", "problem_description", "comment", "review_worker",
            "client_id", "delivery_for_repairs_id", "worker_id", "repair_work_id", "device_id", "service_center_id"};

    String identification = null;



    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        record_repairViewModel = ViewModelProviders.of(this).get(RecordRepairViewModel.class);

        View root = inflater.inflate(R.layout.fragment_record_repair, container, false);

//        final TextView textView = (TextView)root.findViewById(R.id.textView);
//        record_repairViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
//            @Override
//            public void onChanged(@Nullable String s) {
//                textView.setText(s);
//            }
//        });

        textView = (TextView)root.findViewById(R.id.textView);

        editTextID = (EditText) root.findViewById(R.id.editTextID);
        editTextStartData = (EditText) root.findViewById(R.id.editTextStartData);
        editTextEndData = (EditText) root.findViewById(R.id.editTextEndData);
        editTextPaymentMethod = (EditText) root.findViewById(R.id.editTextPaymentMethod);
        editTextQuality = (EditText) root.findViewById(R.id.editTextQuality);
        editTextUrgency = (EditText) root.findViewById(R.id.editTextUrgency);
        editTextGuarantee = (EditText) root.findViewById(R.id.editTextGuarantee);
        editTextProblemDescription = (EditText) root.findViewById(R.id.editTextProblemDescription);
        editTextComment = (EditText) root.findViewById(R.id.editTextComment);
        editTextReviewWorker = (EditText) root.findViewById(R.id.editTextReviewWorker);
        editTextClientID = (EditText) root.findViewById(R.id.editTextClientID);
        editTextDeliveryForRepairsID = (EditText) root.findViewById(R.id.editTextDeliveryForRepairsID);
        editTextWorkerID = (EditText) root.findViewById(R.id.editTextWorkerID);
        editTextRepairWorkID = (EditText) root.findViewById(R.id.editTextRepairWorkID);
        editTextDeviceID = (EditText) root.findViewById(R.id.editTextDeviceID);
        editTextServiceCenterID = (EditText) root.findViewById(R.id.editTextServiceCenterID);

        editTextIdentification = (EditText) root.findViewById(R.id.editTextIdentification);

        btnSendRequestPOST = (Button)root.findViewById(R.id.btnSendRequestPOST);          // Кнопка "Отправить"
        btnSendRequestPOST.requestFocus();
        btnEditEntryClientPOST = (Button)root.findViewById(R.id.btnEditEntryClientPOST);  // Кнопка "Изменить"
        btnDownloadClient = (Button)root.findViewById(R.id.btnDownloadClient);            // Кнопка "Загрузить форму"

        // Кнопка "Зарегестрировать"
        btnSendRequestPOST.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerClient();
            }
        });

        // Кнопка "Изменить данные"
        btnEditEntryClientPOST.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editEntryClient();
            }
        });

        // Кнопка "Загрузить форму"
        btnDownloadClient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                downloadClient();
            }
        });

        // Скроллинг
        textView.setMovementMethod(new ScrollingMovementMethod());

        editTextID.setHorizontallyScrolling(true);
        editTextStartData.setHorizontallyScrolling(true);
        editTextEndData.setHorizontallyScrolling(true);
        editTextPaymentMethod.setHorizontallyScrolling(true);
        editTextQuality.setHorizontallyScrolling(true);
        editTextUrgency.setHorizontallyScrolling(true);
        editTextGuarantee.setHorizontallyScrolling(true);
        editTextProblemDescription.setHorizontallyScrolling(true);
        editTextComment.setHorizontallyScrolling(true);
        editTextServiceCenterID.setHorizontallyScrolling(true);
        editTextReviewWorker.setHorizontallyScrolling(true);
        editTextClientID.setHorizontallyScrolling(true);
        editTextDeliveryForRepairsID.setHorizontallyScrolling(true);
        editTextWorkerID.setHorizontallyScrolling(true);
        editTextRepairWorkID.setHorizontallyScrolling(true);
        editTextDeviceID.setHorizontallyScrolling(true);
        editTextServiceCenterID.setHorizontallyScrolling(true);


        // Обработка выпадающего окна
        Spinner spinner = (Spinner) root.findViewById(R.id.spinner);
        // Создаем адаптер ArrayAdapter с помощью массива строк и стандартной разметки элемета spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity().getApplicationContext(), android.R.layout.simple_spinner_item, countries);
        // Определяем разметку для использования при выборе элемента
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Применяем адаптер к элементу spinner
        spinner.setAdapter(adapter);
        AdapterView.OnItemSelectedListener itemSelectedListener = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Получаем выбранный объект
                String item = (String)parent.getItemAtPosition(position);
                identification = item;
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        };
        spinner.setOnItemSelectedListener(itemSelectedListener);


        return root;
    }



    // Кнопка "Зарегестрировать рабочего"
    public void registerClient() {
        err = 0; errorText = "Вы не указали: ";
//        if(editTextName.getText().toString().equals(""))             { errorText = errorText + "Имя ";               err = 1; }
//        if(editTextSurname.getText().toString().equals(""))          { errorText = errorText + "Фамилию ";           err = 1; }
//        if(editTextAddress.getText().toString().equals(""))          { errorText = errorText + "Адрес ";             err = 1; }
//        if(editTextPhone.getText().toString().equals(""))            { errorText = errorText + "Телефон ";           err = 1; }
//        if(editTextEmail.getText().toString().equals(""))            { errorText = errorText + "Email ";             err = 1; }
//        if(editTextEducation.getText().toString().equals(""))        { errorText = errorText + "Образование ";       err = 1; }
//        if(editTextAccessComplexity.getText().toString().equals("")) { errorText = errorText + "Сложность доступа "; err = 1; }
//        if(editTextPriceMultiplier.getText().toString().equals(""))  { errorText = errorText + "Множитель цены ";    err = 1; }
//        if(editTextPosition.getText().toString().equals(""))         { errorText = errorText + "Должность ";         err = 1; }
//        if(editTextServiceCenterID.getText().toString().equals(""))  { errorText = errorText + "Связь с СЦ ";        err = 1; }

        if(err == 0){
            Toast.makeText(getActivity().getApplicationContext(), "Запрос отправлен на сервер", Toast.LENGTH_LONG).show();
            editTextID.setText("");
            serverNumberPOST = 3;
            new com.example.servicecenterallinone.ui.recordRepair.RecordRepairFragment.MyAsyncTaskPOST().execute();
        }
        if(err == 1){
            Toast.makeText(getActivity().getApplicationContext(), errorText, Toast.LENGTH_LONG).show();
        }
    }



    // Кнопка "Изменить" Редактирование данных о клиенте
    public void editEntryClient(){
        // Проверка на пустое поле ввода индекса записи
        if(editTextIdentification.getText().toString().equals("")){
            Toast.makeText(getActivity().getApplicationContext(), "Вы не указали: Индекс формы", Toast.LENGTH_LONG).show();
        }
        else{
            Toast.makeText(getActivity().getApplicationContext(), "Запрос отправлен на сервер", Toast.LENGTH_LONG).show();
            serverNumberPOST = 2;
            new com.example.servicecenterallinone.ui.recordRepair.RecordRepairFragment.MyAsyncTaskPOST().execute();
        }
    }



    // Кнопка "Загрузить форму"
    public void downloadClient(){
        // Проверка на пустое поле ввода индекса записи
        if(editTextIdentification.getText().toString().equals("")){
            Toast.makeText(getActivity().getApplicationContext(), "Вы не указали Идентификатор", Toast.LENGTH_LONG).show();
        }
        else{
            Toast.makeText(getActivity().getApplicationContext(), "Запрос отправлен на сервер", Toast.LENGTH_LONG).show();
            serverNumberGET = 6;
            new com.example.servicecenterallinone.ui.recordRepair.RecordRepairFragment.MyAsyncTaskGET().execute();
        }
    }



    // Серверная часть   Отправка GET запроса
    class MyAsyncTaskGET extends AsyncTask<String, String, String> {
        String a = null;
        String b = null;
        String c = null;

        String server = null;
        String serverAndData = null;
        String answerHTTP = null;

        String id = null;
        String start_data = null;
        String end_data = null;
        String payment_method = null;
        String quality = null;
        String urgency = null;
        String guarantee = null;
        String problem_description = null;
        String comment = null;
        String review_worker = null;
        String client_id = null;
        String delivery_for_repairs_id = null;
        String worker_id = null;
        String repair_work_id = null;
        String device_id = null;
        String service_center_id = null;

        @Override
        protected void onPreExecute() {
            a = identification;
            b = editTextIdentification.getText().toString();
            c = "record_repair";
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... params) {
            HttpClient httpclient = new DefaultHttpClient();
            // Передаём название таблицы и возвращаем все её данные
            if(serverNumberGET==4) { server = "http://cc33953.tmweb.ru/php/SC_ReturningTable.php"; serverAndData = server + "?a=" + a; }
            // Подаём Идентификатор записи клиента и возвращаем все его данные
            if(serverNumberGET==6) { server = "http://cc33953.tmweb.ru/php/SC_ReturnOneEntry.php"; serverAndData = server + "?a=" + a + "&b=" + b + "&c=" + c; }

            HttpGet httpget = new HttpGet(serverAndData);

            try {
                HttpResponse response = httpclient.execute(httpget);
                if (response.getStatusLine().getStatusCode() == 200) {
                    HttpEntity entity = response.getEntity();
                    answerHTTP = EntityUtils.toString(entity);
                }
            }
            catch (ClientProtocolException e) {
            }
            catch (IOException e) {
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            answerHTTP = outSpecialCharactersHTML (answerHTTP);
            try {
                JSONObject jsonClientInfo = new JSONObject(answerHTTP);

                id                      = jsonClientInfo.getString("id");
                start_data              = jsonClientInfo.getString("start_data");
                end_data                = jsonClientInfo.getString("end_data");
                payment_method          = jsonClientInfo.getString("payment_method");
                quality                 = jsonClientInfo.getString("quality");
                urgency                 = jsonClientInfo.getString("urgency");
                guarantee               = jsonClientInfo.getString("guarantee");
                problem_description     = jsonClientInfo.getString("problem_description");
                comment                 = jsonClientInfo.getString("comment");
                review_worker           = jsonClientInfo.getString("review_worker");
                client_id               = jsonClientInfo.getString("client_id");
                delivery_for_repairs_id = jsonClientInfo.getString("delivery_for_repairs_id");
                worker_id               = jsonClientInfo.getString("worker_id");
                repair_work_id          = jsonClientInfo.getString("repair_work_id");
                device_id               = jsonClientInfo.getString("device_id");
                service_center_id       = jsonClientInfo.getString("service_center_id");

                editTextID.                    setText(id);
                editTextStartData.             setText(start_data);
                editTextEndData.               setText(end_data);
                editTextPaymentMethod.         setText(payment_method);
                editTextQuality.               setText(quality);
                editTextUrgency.               setText(urgency);                                                                                                                 ;
                editTextGuarantee.             setText(guarantee);
                editTextProblemDescription.    setText(problem_description);
                editTextComment.               setText(comment);
                editTextReviewWorker.          setText(review_worker);
                editTextClientID.              setText(client_id);
                editTextDeliveryForRepairsID.  setText(delivery_for_repairs_id);
                editTextWorkerID.              setText(worker_id);
                editTextRepairWorkID.          setText(repair_work_id);
                editTextDeviceID.              setText(device_id);
                editTextServiceCenterID.       setText(service_center_id);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }



    // Серверная часть   Отправка POST запроса
    class MyAsyncTaskPOST extends AsyncTask<String, String, String> {
        String a = null;
        String b = null;
        String c = null;

        String answerHTTP;
        String server;

        String id_RecordRepair                      = null;
        String start_data_RecordRepair              = null;
        String end_data_RecordRepair                = null;
        String payment_method_RecordRepair          = null;
        String quality_RecordRepair                 = null;
        String urgency_RecordRepair                 = null;
        String guarantee_RecordRepair               = null;
        String problem_description_RecordRepair     = null;
        String comment_RecordRepair                 = null;
        String review_worker_RecordRepair           = null;
        String client_id_RecordRepair               = null;
        String delivery_for_repairs_id_RecordRepair = null;
        String worker_id_RecordRepair               = null;
        String repair_work_id_RecordRepair          = null;
        String device_id_RecordRepair               = null;
        String service_center_id_RecordRepair       = null;

        @Override
        protected void onPreExecute() {
            a = "record_repair";
            b = "record_repair";
            c = "record_repair";

            id_RecordRepair                      = editTextID.getText().toString();
            start_data_RecordRepair              = editTextStartData.getText().toString();
            end_data_RecordRepair                = editTextEndData.getText().toString();
            payment_method_RecordRepair          = editTextPaymentMethod.getText().toString();
            quality_RecordRepair                 = editTextQuality.getText().toString();
            urgency_RecordRepair                 = editTextUrgency.getText().toString();
            guarantee_RecordRepair               = editTextGuarantee.getText().toString();
            problem_description_RecordRepair     = editTextProblemDescription.getText().toString();
            comment_RecordRepair                 = editTextComment.getText().toString();
            review_worker_RecordRepair           = editTextReviewWorker.getText().toString();
            client_id_RecordRepair               = editTextClientID.getText().toString();
            delivery_for_repairs_id_RecordRepair = editTextDeliveryForRepairsID.getText().toString();
            worker_id_RecordRepair               = editTextWorkerID.getText().toString();
            repair_work_id_RecordRepair          = editTextRepairWorkID.getText().toString();
            device_id_RecordRepair               = editTextDeviceID.getText().toString();
            service_center_id_RecordRepair       = editTextServiceCenterID.getText().toString();

            super.onPreExecute();
        }
        @Override
        protected String doInBackground(String... params) {
            if(serverNumberPOST == 2) server = "http://cc33953.tmweb.ru/php/SC_EditEntry.php";          // Изменение данных о клиенте
            if(serverNumberPOST == 3) server = "http://cc33953.tmweb.ru/php/SC_RecordRegistration.php"; // Добавление нового клиента

            HashMap<String, String> postDataParams = new HashMap<String, String>();

            postDataParams.put("a", a);
            postDataParams.put("b", b);
            postDataParams.put("c", c);

            postDataParams.put("id_RecordRepair",                      id_RecordRepair);
            postDataParams.put("start_data_RecordRepair",              start_data_RecordRepair);
            postDataParams.put("end_data_RecordRepair",                end_data_RecordRepair);
            postDataParams.put("payment_method_RecordRepair",          payment_method_RecordRepair);
            postDataParams.put("quality_RecordRepair",                 quality_RecordRepair);
            postDataParams.put("urgency_RecordRepair",                 urgency_RecordRepair);
            postDataParams.put("guarantee_RecordRepair",               guarantee_RecordRepair);
            postDataParams.put("problem_description_RecordRepair",     problem_description_RecordRepair);
            postDataParams.put("comment_RecordRepair",                 comment_RecordRepair);
            postDataParams.put("review_worker_RecordRepair",           review_worker_RecordRepair);
            postDataParams.put("client_id_RecordRepair",               client_id_RecordRepair);
            postDataParams.put("delivery_for_repairs_id_RecordRepair", delivery_for_repairs_id_RecordRepair);
            postDataParams.put("worker_id_RecordRepair",               worker_id_RecordRepair);
            postDataParams.put("repair_work_id_RecordRepair",          repair_work_id_RecordRepair);
            postDataParams.put("device_id_RecordRepair",               device_id_RecordRepair);
            postDataParams.put("service_center_id_RecordRepair",       service_center_id_RecordRepair);

            answerHTTP = performPostCall(server, postDataParams);
            return null;
        }
        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

        }
    }



    public String performPostCall(String requestURL, HashMap<String, String> postDataParams) {
        URL url;
        String response = "";
        try {
            url = new URL(requestURL);

            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(15000);
            conn.setConnectTimeout(15000);
            conn.setRequestMethod("POST");
            conn.setDoInput(true);
            conn.setDoOutput(true);

            OutputStream os = conn.getOutputStream();
            BufferedWriter writer = new BufferedWriter(
                    new OutputStreamWriter(os, "UTF-8"));
            writer.write(getPostDataString(postDataParams));

            writer.flush();
            writer.close();
            os.close();
            int responseCode = conn.getResponseCode();

            if (responseCode == HttpsURLConnection.HTTP_OK) {
                String line;
                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                while ((line = br.readLine()) != null) {
                    response += line;
                }
            } else {
                response = "";

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return response;
    }



    private String getPostDataString(HashMap<String, String> params) throws UnsupportedEncodingException {
        StringBuilder result = new StringBuilder();
        boolean first = true;
        for (Map.Entry<String, String> entry : params.entrySet()) {
            if (first)
                first = false;
            else
                result.append("&");

            result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
        }

        return result.toString();
    }



    private String outSpecialCharactersHTML (String a){
        // Знаки пунктуации
        a = a.replaceAll("&nbsp;"," ");         // Неразрывный пробел
        a = a.replaceAll("&shy;","\n");         // Место возможного переноса
        a = a.replaceAll("&lt;","<");           // Знак "меньше чем" (начало тега)
        a = a.replaceAll("&gt;",">");           // Знак "больше чем" (конец тега)
        a = a.replaceAll("&laquo;","«");        // Левая двойная угловая скобка
        a = a.replaceAll("&raquo;","»");        // Правая двойная угловая скобка
        a = a.replaceAll("&lsaquo;","‹");       // Левая угловая одиночная кавычка
        a = a.replaceAll("&rsaquo;","›");       // Правая угловая одиночная кавычка
        a = a.replaceAll("&quot;","\"");        // Двойная кавычка
        a = a.replaceAll("&prime;","'");        // Одиночный штрих
        a = a.replaceAll("&Prime;","″");        // Двойной штрих
        a = a.replaceAll("&lsquo;","‘");        // Левая одиночная кавычка
        a = a.replaceAll("&rsquo;","’");        // Правая одиночная кавычка
        a = a.replaceAll("&sbquo;","‚");        // Нижняя одиночная кавычка
        a = a.replaceAll("&ldquo;","“");        // Левая двойная кавычка
        a = a.replaceAll("&rdquo;","”");        // Правая двойная кавычка
        a = a.replaceAll("&bdquo;","„");        // Нижняя двойная кавычка
        a = a.replaceAll("&#10076;","❜");       // Жирная одинарная верхняя запятая
        a = a.replaceAll("&#10075;","❛");       // Жирная одинарная повёрнутая верхняя запятая
        a = a.replaceAll("&apos;","'");         // Апостроф (одинарная кавычка)
        a = a.replaceAll("&sect;","§");         // Параграф
        a = a.replaceAll("&copy;","©");         // Знак copyright
        a = a.replaceAll("&not;","¬");          // Знак отрицания
        a = a.replaceAll("&reg;","®");          // Знак зарегистрированной торговой марки
        a = a.replaceAll("&macr;","¯");         // Знак долготы над гласным
        a = a.replaceAll("&deg;","°");          // Градус
        a = a.replaceAll("&plusmn;","±");       // Плюс-минус
        a = a.replaceAll("&sup1;","¹");         // Верхний индекс "1"
        a = a.replaceAll("&sup2;","²");         // Верхний индекс "2"
        a = a.replaceAll("&sup3;","³");         // Верхний индекс "3"
        a = a.replaceAll("&frac14;","¼");       // Одна четверть
        a = a.replaceAll("&frac12;","½");       // Одна вторая
        a = a.replaceAll("&frac34;","¾");       // Три четверти
        a = a.replaceAll("&acute;","´");        // Знак ударения
        a = a.replaceAll("&micro;","µ");        // Микро
        a = a.replaceAll("&para;","¶");         // Знак абзаца
        a = a.replaceAll("&middot;","·");       // Знак умножения
        a = a.replaceAll("&iquest;","¿");     // Перевернутый вопросительный знак
        a = a.replaceAll("&fnof;","ƒ");         // Знак флорина
        a = a.replaceAll("&trade;","™");        // Знак торговой марки
        a = a.replaceAll("&bull;","•");         // Маркер списка
        a = a.replaceAll("&hellip;","…");       // Многоточие
        a = a.replaceAll("&oline;","‾");        // Надчеркивание
        a = a.replaceAll("&ndash;","–");        // Среднее тире
        a = a.replaceAll("&mdash;","—");        // Длинное тире
        a = a.replaceAll("&#37;","%");          // Процент
        a = a.replaceAll("&permil;","‰");       // Промилле
        a = a.replaceAll("&#125;","}");         // Правая фигурная скобка
        a = a.replaceAll("&#123;","{");         // Левая фигурная скобка
        a = a.replaceAll("&#61;","=");          // Знак равенства
        a = a.replaceAll("&ne;","≠");           // Знак неравенства
        a = a.replaceAll("&cong;","≅");         // Конгруэнтность (геометрическое равенство)
        a = a.replaceAll("&asymp;","≈");        // Почти равно
        a = a.replaceAll("&le;","≤");           // Меньше чем или равно
        a = a.replaceAll("&ge;","≥");           // Больше чем или равно
        a = a.replaceAll("&ang;","∠");          // Угол
        a = a.replaceAll("&perp;","⊥");         // Перпендикулярно (кнопка вверх)
        a = a.replaceAll("&radic;","√");        // Квадратный корень
        a = a.replaceAll("&sum;","∑");          // N-ичное суммирование
        a = a.replaceAll("&int;","∫");          // Интеграл
        a = a.replaceAll("&#8251;","※");       // Знак сноски
        a = a.replaceAll("&divide;","÷");       // Знак деления
        a = a.replaceAll("&infin;","∞");        // Знак бесконечности
        a = a.replaceAll("&#64;","@");          // Символ собака
        a = a.replaceAll("&#91;","\\[");        // Левая квадратная скобка
        a = a.replaceAll("&#93;","\\]");        // Правая квадратная скобка
        // Стрелки
        a = a.replaceAll("&larr;","←");         // Стрелка влево
        a = a.replaceAll("&uarr;","↑");         // Стрелка вверх
        a = a.replaceAll("&rarr;","→");         // Стрелка вправо
        a = a.replaceAll("&darr;","↓");         // Стрелка вниз
        a = a.replaceAll("&harr;","↔");         // Стрелка влево-вправо
        a = a.replaceAll("&crarr;","↵");        // Стрелка вниз и влево – знак возврата каретки
        a = a.replaceAll("&lArr;","⇐");         // Двойная стрелка налево
        a = a.replaceAll("&uArr;","⇑");         // Двойная стрелка вверх
        a = a.replaceAll("&rArr;","⇒");         // Двойная стрелка направо
        a = a.replaceAll("&dArr;","⇓");         // Двойная стрелка вниз
        a = a.replaceAll("&hArr;","⇔");         // Двойная стрелка влево-вправо
        a = a.replaceAll("&#10144;","➠");       // Летящая стрела
        a = a.replaceAll("&#10148;","➤");       // Наконечник стрелы
        a = a.replaceAll("&#10149;","➥");       // Изогнутая стрела, указывающая вниз и вправо
        a = a.replaceAll("&#10150;","➦");       // Изогнутая стрела, указывающая вверх и вправо
        a = a.replaceAll("&#10163;","➳");       // Стрела направо
        a = a.replaceAll("&#8634;","↺");        // Круглая стрелка с наконечником против часовой стрелки
        a = a.replaceAll("&#8635;","↻");        // Круглая стрелка с наконечником по часовой стрелке
        a = a.replaceAll("&#8679;","⇧");        // Толстая полая стрелка вверх
        a = a.replaceAll("&#8617;","↩");        // Стрелка налево с крючком
        a = a.replaceAll("&#10155;","➫");       // Наклонённая вниз объёмная стрелка
        a = a.replaceAll("&#11015;","⬇");       // Закрашенная стрелка вниз
        a = a.replaceAll("&#11014;","⬆");       // Закрашенная стрелка вверх
        // Деньги
        a = a.replaceAll("&cent;","¢");         // Цент
        a = a.replaceAll("&pound;","£");        // Фунт стерлингов
        a = a.replaceAll("&#8381;","₽");        // Российский рубль
        a = a.replaceAll("&yen;","¥");          // Йена или юань
        a = a.replaceAll("&euro;","€");         // Евро
        a = a.replaceAll("&#36;","$");          // Доллар
        a = a.replaceAll("&#8372;","₴");        // Знак гривны
        a = a.replaceAll("&#8377;","₹");        // Индийская рупия
        a = a.replaceAll("&#22291;","圓");       // Китайский юань
        a = a.replaceAll("&#8376;","₸");        // Казахстанский тенге

        return a;
    }

}